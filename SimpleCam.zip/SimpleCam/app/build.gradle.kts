plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.simplecam"
    compileSdk = 34
    defaultConfig { applicationId = "com.simplecam"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17"; freeCompilerArgs += "-opt-in=androidx.camera.camera2.interop.ExperimentalCamera2Interop" }
}
dependencies {
    val v = "1.3.4"
    implementation("androidx.camera:camera-core:$v")
    implementation("androidx.camera:camera-camera2:$v")
    implementation("androidx.camera:camera-lifecycle:$v")
    implementation("androidx.camera:camera-view:$v")
    implementation("androidx.camera:camera-extensions:$v")
    implementation("androidx.camera:camera-video:$v")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
