package com.simplecam

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.graphics.Outline
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.net.Uri
import android.content.Intent
import android.util.Size
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.FrameLayout
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var shutter: View
    private var provider: ProcessCameraProvider? = null
    private var ext: ExtensionsManager? = null
    private var capture: ImageCapture? = null
    private var video: VideoCapture<Recorder>? = null
    private var rec: Recording? = null
    private var front = false
    private var modeIdx = 2
    private val modes = listOf("NIGHT", "VIDEO", "PHOTO", "PORTRAIT")
    private var camera: Camera? = null
    private var flashOn = false
    private var lastUri: Uri? = null
    private var scaling = false
    private val h = Handler(Looper.getMainLooper())
    private var secs = 0
    private val modeViews = mutableListOf<TextView>()
    private val zoomViews = mutableListOf<TextView>()
    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        preview = findViewById(R.id.preview)
        preview.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        preview.clipToOutline = true
        preview.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(18).toFloat()) }
        }
        shutter = findViewById(R.id.shutter)
        val flashBtn = findViewById<TextView>(R.id.flash)
        flashBtn.setOnClickListener {
            flashOn = !flashOn
            flashBtn.setTextColor(if (flashOn) Color.parseColor("#FFD60A") else Color.WHITE)
            capture?.flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
            if (modeIdx == 1) camera?.cameraControl?.enableTorch(flashOn)
        }
        shutter.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            it.animate().scaleX(0.88f).scaleY(0.88f).setDuration(70).withEndAction { it.animate().scaleX(1f).scaleY(1f).setDuration(90).start() }.start()
            if (modeIdx == 1) toggleRec() else shoot()
        }
        findViewById<View>(R.id.flip).setOnClickListener { if (rec == null) { front = !front; bind() } }
        findViewById<View>(R.id.thumb).setOnClickListener {
            lastUri?.let { u -> startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "image/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
        }
        // iPhone jaisa mode selector (selected = peela)
        val row = findViewById<android.widget.LinearLayout>(R.id.modeRow)
        modes.forEachIndexed { i, m ->
            val t = TextView(this).apply {
                text = m; textSize = 13f; gravity = Gravity.CENTER; typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                setOnClickListener { if (rec == null) { modeIdx = i; styleModes(); bind() } }
            }
            modeViews.add(t); row.addView(t)
        }
        styleModes()
        // Zoom buttons .5 / 1x / 2x
        val zr = findViewById<android.widget.LinearLayout>(R.id.zoomRow)
        listOf(".5" to 0.5f, "1×" to 1f, "2×" to 2f).forEach { (lbl, r) ->
            val t = TextView(this).apply {
                text = lbl; textSize = 13f; gravity = Gravity.CENTER; setTextColor(if (r == 1f) Color.parseColor("#FFD60A") else Color.WHITE)
                typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
                layoutParams = android.widget.LinearLayout.LayoutParams(dp(40), dp(40)).also { it.setMargins(dp(2), 0, dp(2), 0) }
                tag = r
                setOnClickListener {
                    camera?.cameraControl?.setZoomRatio(r)
                    zoomViews.forEach { z -> z.setTextColor(if (z === this) Color.parseColor("#FFD60A") else Color.WHITE) }
                }
            }
            zoomViews.add(t); zr.addView(t)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) start()
        else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1)
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(c, p, r)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) start()
    }

    private fun styleModes() {
        modeViews.forEachIndexed { i, t -> t.setTextColor(if (i == modeIdx) Color.parseColor("#FFD60A") else Color.WHITE) }
    }

    private fun showFocus(x: Float, y: Float) {
        val b = findViewById<View>(R.id.focusBox)
        val loc = IntArray(2); preview.getLocationInWindow(loc)
        val root = IntArray(2); (b.parent as View).getLocationInWindow(root)
        b.x = loc[0] - root[0] + x - b.width / 2f; b.y = loc[1] - root[1] + y - b.height / 2f
        b.visibility = View.VISIBLE; b.alpha = 1f; b.scaleX = 1.3f; b.scaleY = 1.3f
        b.animate().scaleX(1f).scaleY(1f).setDuration(150).withEndAction { b.animate().alpha(0f).setStartDelay(900).setDuration(300).start() }.start()
    }

    private fun start() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            provider = f.get()
            val ef = ExtensionsManager.getInstanceAsync(this, provider!!)
            ef.addListener({ ext = ef.get(); bind() }, ContextCompat.getMainExecutor(this))
        }, ContextCompat.getMainExecutor(this))
    }

    // Fast autofocus + fast shutter + high quality noise/edge (sirf jab extension use nahi ho raha)
    private fun <T> tune(b: ExtendableBuilder<T>, info: CameraInfo, forVideo: Boolean) {
        val e = Camera2Interop.Extender(b)
        e.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE,
            if (forVideo) CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO else CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        if (!forVideo) {
            val ranges = Camera2CameraInfo.from(info)
                .getCameraCharacteristic(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            // lower=30 => exposure 1/30s se lambi nahi hogi => kam motion blur
            ranges?.filter { it.lower == 30 }?.maxByOrNull { it.upper }
                ?.let { e.setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) }
            e.setCaptureRequestOption(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
            e.setCaptureRequestOption(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_HIGH_QUALITY)
        }
    }

    private fun bind() {
        val p = provider ?: return
        val isVideo = modeIdx == 1
        val base = if (front) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
        val info = p.getCameraInfo(base)
        var sel = base
        var extOn = false
        if (!isVideo) {
            // PHOTO me pehle HDR try hota hai, na ho to AUTO
            val order = when (modeIdx) {
                2 -> listOf(ExtensionMode.HDR, ExtensionMode.AUTO)
                0 -> listOf(ExtensionMode.NIGHT)
                else -> listOf(ExtensionMode.BOKEH, ExtensionMode.FACE_RETOUCH)
            }
            order.firstOrNull { ext?.isExtensionAvailable(base, it) == true }?.let {
                sel = ext!!.getExtensionEnabledCameraSelector(base, it); extOn = true
            }
        }
        val pb = Preview.Builder()
        if (isVideo && Preview.getPreviewCapabilities(info).isStabilizationSupported) pb.setPreviewStabilizationEnabled(true)
        if (!extOn) tune(pb, info, isVideo)
        val prev = pb.build().also { it.setSurfaceProvider(preview.surfaceProvider) }
        p.unbindAll()
        camera = if (isVideo) {
            val rb = Recorder.Builder().setQualitySelector(QualitySelector.fromOrderedList(
                listOf(Quality.FHD, Quality.HD, Quality.UHD), FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)))
            val vb = VideoCapture.Builder(rb.build())
            // Strong EIS: 1080p pe sabse achha chalta hai
            if (Recorder.getVideoCapabilities(info).isStabilizationSupported) vb.setVideoStabilizationEnabled(true)
            tune(vb, info, true)
            video = vb.build(); capture = null
            p.bindToLifecycle(this, sel, prev, video!!)
        } else {
            val res = ResolutionSelector.Builder().setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY).build()
            val cb = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setResolutionSelector(res).setJpegQuality(98)
            if (!extOn) tune(cb, info, false)
            cb.setFlashMode(if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF)
            capture = cb.build(); video = null
            p.bindToLifecycle(this, sel, prev, capture!!)
        }
        shutter.setBackgroundResource(if (isVideo) R.drawable.shutter_vid else R.drawable.shutter)
        zoomViews.forEach { z -> z.setTextColor(if (z.tag == 1f) Color.parseColor("#FFD60A") else Color.WHITE) }
        val sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(d: ScaleGestureDetector): Boolean { scaling = true; return true }
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val z = camera?.cameraInfo?.zoomState?.value ?: return true
                camera?.cameraControl?.setZoomRatio(z.zoomRatio * d.scaleFactor); return true
            }
            override fun onScaleEnd(d: ScaleGestureDetector) { h.postDelayed({ scaling = false }, 200) }
        })
        preview.setOnTouchListener { v, e ->
            sd.onTouchEvent(e)
            if (e.action == MotionEvent.ACTION_UP && !scaling && e.pointerCount == 1) {
                val pt = preview.meteringPointFactory.createPoint(e.x, e.y)
                camera?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                showFocus(e.x, e.y); v.performClick()
            }; true
        }
    }

    private fun toggleRec() {
        val v = video ?: return
        if (rec != null) { rec?.stop(); return }
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "VID_${System.currentTimeMillis()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/SimpleCam")
        }
        val o = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI).setContentValues(cv).build()
        var pr = v.output.prepareRecording(this, o)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) pr = pr.withAudioEnabled()
        rec = pr.start(ContextCompat.getMainExecutor(this)) { e ->
            if (e is VideoRecordEvent.Finalize) {
                shutter.setBackgroundResource(R.drawable.shutter_vid); rec = null
                findViewById<View>(R.id.timer).visibility = View.GONE; camera?.cameraControl?.enableTorch(false)
                Toast.makeText(this, if (e.hasError()) "Video error" else "Video saved", Toast.LENGTH_SHORT).show()
            }
        }
        shutter.setBackgroundResource(R.drawable.shutter_rec)
        camera?.cameraControl?.enableTorch(flashOn)
        secs = 0
        val tv = findViewById<TextView>(R.id.timer); tv.visibility = View.VISIBLE; tv.text = "00:00"
        h.post(object : Runnable { override fun run() {
            if (rec == null) return
            secs++; tv.text = "%02d:%02d".format(secs / 60, secs % 60); h.postDelayed(this, 1000) } })
    }

    private fun shoot() {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "IMG_${System.currentTimeMillis()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/SimpleCam")
        }
        val out = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv).build()
        val fo = findViewById<View>(R.id.flashOverlay)
        fo.visibility = View.VISIBLE; fo.alpha = 0.7f
        fo.animate().alpha(0f).setDuration(180).withEndAction { fo.visibility = View.GONE }.start()
        capture?.takePicture(out, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                val u = r.savedUri ?: return
                lastUri = u
                Thread {
                    try {
                        val th = if (Build.VERSION.SDK_INT >= 29) contentResolver.loadThumbnail(u, Size(256, 256), null) else null
                        runOnUiThread { val iv = findViewById<ImageView>(R.id.thumb); iv.clipToOutline = true
                            iv.outlineProvider = ViewOutlineProvider.BACKGROUND
                            if (th != null) iv.setImageBitmap(th) else iv.setImageURI(u) }
                    } catch (ex: Exception) {}
                }.start()
            }
            override fun onError(e: ImageCaptureException) { Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show() }
        })
    }
}
